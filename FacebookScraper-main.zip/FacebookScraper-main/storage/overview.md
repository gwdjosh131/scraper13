# Facebook Group Web Scraping Project

## System Overview
The system is a web scraping algorithm designed to extract data from the **Secret Montclair** Facebook group. It is implemented as a set of **Python scripts** with a terminal-based user interface (UI).  

To bypass Facebook’s anti-bot mechanisms, the system **emulates human behavior**, allowing it to interact with the platform without detection. It achieves this by dynamically scrolling through the group's posts, continuously loading content until no new posts appear. This ensures **comprehensive data collection**.  

---

## Data Collection

### Database Structure  
The scraper captures the following data:  

#### **Posts**
- **Username** of the poster  
- **Date** posted  
- **Post content** (text/caption)  

#### **Comments**
- **Username** of the commenter  
- **Comment text**  

---

## Output Format  
The extracted data can be exported in the following formats:  

- **JSON** – Structured data format for easy integration with databases and APIs  
- **TXT** – Plain text format for simple readability  

---

## Challenges & Considerations  

### JavaScript-Rendered Content  
A significant portion of Facebook posts and comments are dynamically loaded using **JavaScript**, meaning the raw HTML does not contain the necessary data. To address this, the system **interacts with the page as a user would**, executing JavaScript to fully render the content before extraction.  

Examples of elements requiring JavaScript execution include:  
- **Post dates** that are dynamically generated on hover  
- **Long captions** that require user interaction to expand  
- **Lengthy comments** that are hidden behind "see more" buttons  

### Facebook Anti-Bot Restrictions  
Facebook employs sophisticated detection mechanisms to block automated data scraping. To mitigate this:  
- The system **mimics human scrolling and interaction patterns**  
- It introduces **randomized delays** between actions to avoid detection  
- It may incorporate **IP rotation or session handling techniques** to reduce the likelihood of being blocked  

---

